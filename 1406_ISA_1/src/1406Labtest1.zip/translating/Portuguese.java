package translating;

public class Portuguese implements Translate {

	@Override
	public void MakeTranslaton(String text) {
System.out.println("Text to Portuguese\n"+text);
	}

}
