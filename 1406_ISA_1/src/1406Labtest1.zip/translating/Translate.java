package translating;

public interface Translate {
	public void MakeTranslaton(String text);
}
