package translating;

public class German implements Translate {

	@Override
	public void MakeTranslaton(String text) {
		// TODO Auto-generated method stub
		System.out.println("Text to German\n"+text);

	}

}
