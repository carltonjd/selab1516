package translating;

public class FrenchReadyTranslation {
	public void Translaton(String text) {
		// TODO Auto-generated method stub
		System.out.println("Text to French by FrenchReadyTranslation\n"+text);

	}
}
