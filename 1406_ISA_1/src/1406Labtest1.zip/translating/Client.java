package translating;

public class Client {

	public static void main(String[] args) {
		MultiligualSW Software = new MultiligualSW();
		Software.choseLang("French");
		Software.textTranslation("Hello");
		Software.choseLang("Portuguese");
		Software.textTranslation("Hello");
	}

}
