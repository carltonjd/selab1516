package gui;

public interface WindowInterface {
public void minimize();
public void close();

}
