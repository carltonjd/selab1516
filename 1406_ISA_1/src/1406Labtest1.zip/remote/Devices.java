package remote;

public interface Devices {

		boolean switchOn();
		boolean switchOff();
		boolean Play();
		boolean Pause();
	

}
