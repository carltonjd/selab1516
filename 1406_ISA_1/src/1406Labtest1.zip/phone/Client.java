package phone;

public class Client {
	public static void main(String[]args)
	{
		Mobile mobile = new Mobile();
		mobile.pressPhone();
		mobile.on();
		mobile.off();
		mobile.pressCamera();
		mobile.on();
		mobile.off();
		mobile.pressMusic();
		mobile.on();
		mobile.off();

	}
}

