package phone;

public interface Operations {
	public void on();
	public void off();
}
