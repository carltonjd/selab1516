
public class StarSports implements Observer  {
	public void update(int score) {
		System.out.println("StarSports: Score updated, new Score is: " + score);
	}
}
